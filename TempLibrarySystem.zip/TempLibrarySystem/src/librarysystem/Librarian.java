/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysystem;

/**
 *
 * @author Yihe Wang
 */
public class Librarian extends Person{
    
    
    Librarian( String pawPrint,int ID,String lastName,String firstName,String password){
        super(pawPrint,ID,lastName,firstName,password);
    }
}
